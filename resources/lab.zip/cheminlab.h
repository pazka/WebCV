#ifndef CHEMINLAB_H
#define CHEMINLAB_H

#include "libEns.h"
#include "libMat.h"
#include "twist.h"
#include "graph.h"
#include "stack.h"
#include <limits.h>
#include <stdio.h>

Ens getWantToGo(Ens e,matrice * m,int x, int y);
void choixAleatoire(matrice* m);
void heuristique(matrice* m);
void dijkstra(matrice* m);
void astar(matrice* m);
int minDist(int *dist,int *inclus,matrice *m);

#endif
