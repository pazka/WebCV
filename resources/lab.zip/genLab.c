#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#include "genLab.h"

int verbose = 0,nbGraines = 4,pt = 3;

// Pour test,changer le makefile de manière à compiler libMat et libEns.
// Départ = mat[0,1]; Arrivée = mat[h,l-1];

Couple choixRand(int h,int l) 
{
	return coupleCreate((int)(twistExtractU32()%l),(int)(twistExtractU32()%h));
	
}

int estConstructible(int x,int y,matrice* m)
{
	int res = 0;
	if( matVal(y,x,m)==1 || ( x== 1 && y== 1 )|| ( x== m->l-2 && y== m->h-2)){
		return res;
	}
	else if( matVal(y+1,x,m)==1) //Haut
	{
		if( matVal(y,x-1,m)==0 && matVal(y,x+1,m)==0 &&  matVal(y-1,x,m)==0 
			&& matVal(y-1,x-1,m)==0 && matVal(y-1,x+1,m)==0 ){
			res= 1;}
	}
	else if( matVal(y-1,x,m)==1) //Bas
	{
		if( matVal(y,x-1,m)==0 && matVal(y,x+1,m)==0 && matVal(y+1,x,m)==0 
			&& matVal(y+1,x-1,m)==0 && matVal(y+1,x+1,m)==0 ){
			res= 1;}
	}
	else if( matVal(y,x+1,m)==1) //Droite
	{
		if( matVal(y+1,x,m)==0 && matVal(y-1,x,m)==0 && matVal(y,x-1,m)==0  
			&& matVal(y-1,x-1,m)==0 && matVal(y+1,x-1,m)==0 ){
			res= 1;}
	}
	else if( matVal(y,x-1,m)==1) //Gauche
	{
		if( matVal(y+1,x,m)==0 && matVal(y-1,x,m)==0 &&  matVal(y,x+1,m)==0  
			&& matVal(y-1,x+1,m)==0 && matVal(y+1,x+1,m)==0 ){
			res= 1;}
	}
	
	return res;
	
}

Ens AjouteEnsConstructible(int x, int y,matrice* m,Ens e)// c coordonnées d'un mur , e ensemble des cases constructibles
{	
	//haut
	if(estConstructible(x,y+1,m))
		e=ensAjoute(e,x,y+1);
	
	//bas
	if(estConstructible(x,y-1,m))
		e=ensAjoute(e,x,y-1);
	//droite 
	if(estConstructible(x+1,y,m))
		e=ensAjoute(e,x+1,y);
	
	//gauche
	if(estConstructible(x-1,y,m))
		e=ensAjoute(e,x-1,y);
	
	return e;
	
}

int estConstructibleGraine(int x,int y,matrice* m)
{
	int res = 0;
	//afficherCase(x,y,m);
	if( matVal(y,x,m)==1 || ( x== 1 && y== 1 )|| ( x== m->l-2 && y== m->h-2)){
// 		printf("df|inout\n");
		return res;
	}else if( matVal(y-1,x,m)==0 && matVal(y+1,x,m)==0 && matVal(y,x-1,m)==0 && matVal(y,x+1,m)==0){
		res = 1;
	}else if( matVal(y+1,x,m)==1) //Haut
	{
// 		printf("h\n");
		if( matVal(y,x-1,m)==0 && matVal(y,x+1,m)==0 &&  matVal(y-1,x,m)==0 ){
			res= 1;}
	}
	else if( matVal(y-1,x,m)==1) //Bas
	{
// 		printf("b\n");
		if( matVal(y,x-1,m)==0 && matVal(y,x+1,m)==0 && matVal(y+1,x,m)==0){
			res= 1;}
	}
	else if( matVal(y,x+1,m)==1) //Droite
	{
// 		printf("d\n");
		if( matVal(y+1,x,m)==0 && matVal(y-1,x,m)==0 && matVal(y,x-1,m)==0 ){
			res= 1;}
	}
	else if( matVal(y,x-1,m)==1) //Gauche
	{
// 		printf("g\n");
		if( matVal(y+1,x,m)==0 && matVal(y-1,x,m)==0 &&  matVal(y,x+1,m)==0){
			res= 1;}
	}
	
	return res;
	
}

/* Cette fonction intialise la matrice avec les graine dont au moins une près d'un mur
* et les bords ainsi que l'arrivée et la sortie
* 
* RETURN : un ensemlbe de case construite
*/
Ens initMat(int nbGraines,matrice *m){
	int h= m->h,l = m->l;
	srand ( time(NULL));
	Ens ensCstrbl = ensCreateEmpty();
	
	//intialisation des bords, l'arrivée et la sortie
	
	int i=0;
	for(;i<l;i++){//haut et bas
		matSet(1, 0 ,i,m);
		matSet(1,h-1,i,m);
	}
	for(i=0;i<h;i++){//droite et gauche
		matSet(1,i, 0 ,m);
		matSet(1,i,l-1,m);
	}
	
		
	int j;
	//posage des graines sur les murs
	int walledSeeds = 2+(twistExtractU32()%(nbGraines-3));
	nbGraines = nbGraines - walledSeeds;
	int pos,y = 0,x = 0; 
	
	for(i=0;i<walledSeeds;i++){
		pos = 0 | 1<<(twistExtractU32()%4); //selection du mur ou placer la graine
		
		while(!estConstructible(x,y,m) )
		{
			switch(pos){
				case 1: //haut
					y = 1;
					x = 1+twistExtractU32()%(l-3);
					break;
					
				case 2://bas
					y = h-2;
					x = 1+twistExtractU32()%(l-3);
					break;
					
				case 4: //droite
					y = 1+twistExtractU32()%(h-3);
					x = 1;
					break;
					
				case 8://gauche
					y = 1+twistExtractU32()%(h-3);
					x = l-2;
					break;
			}
		}
		
		matSet(1,y,x,m);
	
		ensCstrbl = AjouteEnsConstructible(x,y,m,ensCstrbl); //l'inversion x, y est normale
	}
	//posage des graines dans la matrice
	for(i=0;i<nbGraines;i++){
		x = 1+twistExtractU32()%(l-2);
		y = 1+twistExtractU32()%(h-2);
		
		while(!estConstructibleGraine(x,y,m)) //graine
		{
			x = 1+twistExtractU32()%(l-2);
			y = 1+twistExtractU32()%(h-2);
		}
		
		matSet(1,y,x,m);
		ensCstrbl = AjouteEnsConstructible(x,y,m,ensCstrbl);
	}
	return ensCstrbl;
}

matrice *generationLab(int h, int l)
{
	matrice *m = matAlloc(h,l);
	Ens ensCstrbl = initMat(nbGraines,m);
	Couple cToAdd;
	
	
	if(verbose){
		initgraph(m->l*pt,m->h*pt);
		afficherGraphMat(m,pt);
	}
	//creation de la première liste d'lement constructible
	
	while(!ensEstVide(ensCstrbl))
	{	 
		Couple cToAdd = ensTirage(&ensCstrbl);
		
		//case it was the first among the rest
		if(estConstructible(cToAdd->x,cToAdd->y,m)){
			//mettre un mur
			matSet(1,cToAdd->y,cToAdd->x,m);
			
			ensCstrbl = AjouteEnsConstructible(cToAdd->x,cToAdd->y,m,ensCstrbl); // a sortir de la boucle peut-être
			if(verbose >= 2){
				afficherGraphMat(m,pt);
				afficherConstr(ensCstrbl,pt);
				cleargraph();
			}
			else if(verbose >= 1){
				afficherPoint(cToAdd->x,cToAdd->y,pt);
			}
		}
		free(cToAdd);
	}
	if(verbose >= 1){
		waitgraph();
		closegraph();
	}
	
	ensFree(ensCstrbl);
	return m;	
}

int main(int argc, char *argv[]) {
// 	initgraph(1000,1000); //test
// 	refresh(); //test
	
	int argstart = 1,h = 300,l = 200, opt = 0;
	char* fichier ;
	
	while((opt = getopt(argc,argv,"v d h: l: g: p:")) != -1){
		switch(opt)
		{
			case((int)'h'):
				if(optarg == NULL ){
					fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
					exit(1);
				}
				sscanf(optarg,"%d",&h);
				argstart += 2;
				break;

			case((int)'g'):
				if(optarg == NULL ){
					fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
					exit(1);
				}
				sscanf(optarg,"%d",&nbGraines);
				argstart += 2;
				break; 

			case((int)'p'):
				if(optarg == NULL ){
					fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
					exit(1);
				}
				sscanf(optarg,"%d",&pt);
				argstart += 2;
				break;
  
			case((int)'l'):
				if(optarg == NULL || optarg[0] == '-'){
					fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
					exit(1);
				}
				sscanf(optarg,"%d",&l);
				argstart += 2; 
				break;       

			case((int)'v'):
				verbose += 1;
				argstart ++;
				break; 

			case((int)'d'):
				verbose += 2;
				argstart ++;
				break; 

			default:
				fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
				exit(1);
		} 
	}
	 
	if(argv[argstart] == NULL){
		fprintf(stderr,"usage: %s [-l <largeur>] [-h <hauteur>] [-v showGen] [-d showAdvancedGen] [-g nbGraine] [-p pixelSize]  <fichier> \n",argv[0]);
		exit(1);
	}  
	fichier = argv[argstart];
	
	if(nbGraines> h+l ){
		fprintf(stderr,"Trop de graines\n");
		exit(1);
	}
	if(nbGraines < 4 ){
		fprintf(stderr,"Pas assez de graines (min 4)\n");
		exit(1);
	}   
	if(h < 10 || l < 10){
		fprintf(stderr,"Dimension trop petite, h>10 et l>10\n");
		exit(1);
	}
	 
	twistInitialize(time(NULL)); //twist rand
	
	matrice* m = generationLab(h,l);
	matSauv(m,fichier);
	matFree(m);
	return 0;
}
