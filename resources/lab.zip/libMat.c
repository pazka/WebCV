#include "libMat.h"

matrice* matAlloc(int h,int l)
{
	
	int i;
	int j;
	matrice* m;
	m=malloc(sizeof(matrice));
	m->h=h;
	m->l=l;
	m->content=malloc(sizeof(int)*h*l);
	m->marquage=malloc(sizeof(int)*h*l);
	
	for(j=0;j<h;j++)
	{
		for(i=0;i<l;i++)
		{
			m->content[(j*l)+i]=0;
		}
	}
	
	for(j=0;j<h;j++)
	{
		for(i=0;i<l;i++)
		{
			m->marquage[(j*l)+i]=0;
		}
	}
	
	return m;
	
}

int matFree(matrice *m)
{
	free(m->content);
	free(m->marquage);
	free(m);
}

// limit = 00 et l-1 et h-1
int matVal(int h,int l,matrice* m)
{
	if((h<m->h && h>=0) && ( l< m->l && l>=0))
	{
		return m->content[(h*m->l)+l];
	}
	else
	{
		return (-1);
	}
}

// limit = 00 et l-1 et h-1
int matEstMark(int h,int l,matrice* m)
{
	if((h<m->h && h>=0) && ( l< m->l && l>=0))
	{
		return m->marquage[(h*m->l)+l];
	}
	else
	{
		return (-1);
	}
}

int matMark(int val,int h,int l,matrice* m)
{
	if((h<m->h && h>=0) && ( l< m->l && l>=0))
	{
		m->marquage[(h*m->l)+l]=val;
		return 1;
	}
	else
	{
		return (-1);
	}
}

int matMark2(int val,int ind,matrice* m)
{
	if(ind>0 && ind<m->l*m->h)
	{
		m->marquage[ind]=val;
		return 1;
	}
	else
	{
		return (-1);
	}
}

int matSet(int val,int h,int l,matrice* m)
{
	if((h<m->h && h>=0) && ( l< m->l && l>=0))
	{
		m->content[(h*m->l)+l]=val;
		return 1;
	}
	else
	{
		return (-1);
	}
}

void matSauv(matrice* m,char* path)
{
	FILE* fd;
	int i;
	int j;
	
	fd=fopen(path,"w+");
	if(fd != NULL)
	{
		fprintf(fd,"%d %d\n",m->h,m->l);
		for(j=0;j<m->h;j++)
		{
			
			for(i=0;i<m->l;i++)
			{
				fputc((char)matVal(j,i,m),fd);
			}
			//fprintf(fd, "\n");
		}
		
		fclose(fd);
		
	}
	else
	{
		printf("error\n");
	}
	
	
}

matrice* matLit(char* path)
{

	FILE* fd=fopen(path,"r");
	
	if (fd == NULL)
		return NULL;
	
	unsigned char c;
	int i=0,j=0,l=0,h=0;
	int tmp;
	
	fscanf(fd,"%d %d\n",&h,&l);
	matrice* mat = matAlloc(h,l);
	
	
	for(j=0;j<h;j++)
	{
		for(i=0;i<l;i++)
		{
			tmp = fgetc(fd);
			matSet(tmp,j,i,mat);
		}
	}
	
	
	
	return mat;
	
}


//à virer après la fin des tests
/*
 * int main(int argc, char const *argv[]) {
 * matrice *mat;
 * matrice *m;
 * int i;
 * int j;
 * m=matAlloc(5,7);
 * mat=matAlloc(5,7);
 * //  printf("%d",matVal(2,3,mat));
 * for(i=0;i<mat->h;i++)
 * {
 * for(j=0;j<mat->l;j++)
 * {
 * matSet(0,j,i,mat);
 * }
 * }
 * matSet(1,3,4,mat);
 * 
 * for(i=0;i<mat->h;i++)
 * {
 * for(j=0;j<mat->l;j++)
 * {
 * printf("%d",matVal(i,j,mat));
 * }
 * printf("\n");
 * }
 * //printf("\n%d\n",matVal(2,3,mat));
 * 
 * matSauv(mat,"/mnt/c/Users/Defaut Julian/Desktop/cours/Github/file.txt");
 * m=matLit("/mnt/c/Users/Defaut Julian/Desktop/cours/Github/file.txt");
 * for(i=0;i<mat->h;i++)
 * {
 * for(j=0;j<mat->l;j++)
 * {
 *	printf("%d",matVal(i,j,m));
 * }
 * printf("\n");
 * }
 * return 0;
 * }*/
