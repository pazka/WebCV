#include "libEns.h"

Ens ensAlloc()
{
	Ens e = malloc(sizeof(s_ens));
	if (e)
	{
		e->c = NULL;
		e->eNext = NULL;
		e->taille = 0;
		e->prio = INT_MAX;
	}
	return e;
}

Ens ensCreate(int x, int y)
{
	Ens e = ensAlloc();
	if (e)
	{
		e->c = coupleCreate(x,y);
		e->eNext = NULL;
		e->taille = 1;
		e->prio = INT_MAX;
	}

	return e;
}

Ens ensCreateFromCouple(Couple c)
{
	Ens e = ensAlloc();
	if (e)
	{
		e->c = c;
		e->eNext = NULL;
		e->taille = 1;
		e->prio = INT_MAX;
	}

	return e;
}

Ens ensCreateEmpty()
{
	Ens e = ensAlloc();
	return e;
}

void ensFree(Ens e)
{
	if(e->eNext != NULL)
		ensFree(e->eNext);

	elemFree(e);
}

void elemFree(Ens e)
{
	/* In the main program, we never have to free a whole ensemble
	 * so this free is just a simple free that dosen't delete the whole ensemble
	 */
// 	if(e->c) printf("\n//////FREE (%d,%d)\n",e->c->x,e->c->y);
	free(e->c);
	e->eNext = NULL;
	free(e);
}

Ens ensEmpty(Ens e){
	free(e->c);
	
	if(e->eNext != NULL)
		ensFree(e->eNext);
	
	e->eNext = NULL;
	e->taille = 0;
	e->c = NULL;
	return e;
} 

Couple coupleCreate(int x, int y)
{
	Couple c = malloc(sizeof(s_couple));
	if(c && x <= MAX_VAL && y <= MAX_VAL && x >= 0 && y >= 0)
	{
		c->x = x;
		c->y = y;
		return c;
	}

	return NULL;
}

int  ensEstDans(Ens e,int x, int y)
{
	if(ensEstVide(e->eNext) && !cplcmp(e->c,x,y))
		return 0;
	if(cplcmp(e->c,x,y))
		return 1;

	return ensEstDans(e->eNext,x,y);
}

int cplcmp(Couple a,int x , int y)
{
	if(a == NULL)
		return 0;
	
	if(a == NULL && x == 0 && y == 0)
		return 1;

	return ((a->x == x) && (a->y == y));
}

int  ensEstVide(const Ens e)
{
	if(e == NULL)
		return 1;
	if(e->c == NULL)
		return 1;

	return 0;
}

int  ensTaille(Ens e)
{
/* 	int res = 0;
	Ens etmp = e;
	while(!ensEstVide(etmp))
	{
		res++;
		etmp = etmp->eNext;
 	}*/

	return e->taille ;
}

Ens  ensAjoute(Ens e,int x,int y)
{ 
	//esemble est vide
	if(ensEstVide(e)){
		e->c = coupleCreate(x,y);
		e->taille = 1;
		return e;
	}

	//ensemble n'est pas vide
	Ens etmp = ensCreate(x,y);
	etmp->eNext = e;
	etmp->taille = e->taille+1;
	
	return etmp;
}

Ens  ensAjouteFromCouple(Ens e,Couple c)
{
	if(e->c == NULL){
		e->c = c;
		return e;
	}

	Ens etmp = e;

// 	ensAffiche(etmp,"\n//////ADD: ens going to get c ensAffiche(etmp)");
	while(etmp->eNext != NULL){
		etmp = etmp->eNext;
	}

// 	ensAffiche(etmp,"\n//////ADD:check elem going to get c");
// 	printf("\n//////ADDc: (%d,%d) to (%d,%d)\n",c->x,c->y,etmp->c->x,etmp->c->y);
	Ens etoadd = ensCreateFromCouple(c);
// 	ensAffiche(etmp,"\n//////ADD:check elem going to get enext(c)");
	etmp->eNext = etoadd;
// 	printf("\n//////ADDc:done (%d,%d)\n",c->x,c->y);

	return e;
}

Ens  ensAjouteTriCroissantEns(Ens e,Ens eToAdd){
	//ensemble est vide
	
	if(e->c == NULL){
		free(e);
		return eToAdd;
	}else if(eToAdd->c == NULL){
		free(eToAdd);
		return e;
	}
	
	//ensemble n'est pas vide
	Ens etmp = e;
	while(etmp->eNext != NULL && eToAdd->prio >= etmp->eNext->prio){
		etmp = etmp->eNext;
	}
	
	eToAdd->eNext = etmp->eNext;
	etmp->eNext = eToAdd;
	
	e->taille = e->taille+1;
	
	return e; 
}

Ens  ensAjouteTriCroissant(Ens e,int x, int y,int val){
	//ensemble est vide
	
	if(e->c == NULL){
		e->c = coupleCreate(x,y);
		e->taille = e->taille + 1;
		return e;
	}
	
	//ensemble n'est pas vide
	Ens etmp = e;
	while(etmp->eNext != NULL && val >= etmp->eNext->prio){
		etmp = etmp->eNext;
	}
	
	Ens eToAdd = ensCreate(x,y);
	eToAdd->eNext = etmp->eNext;
	etmp->eNext = eToAdd;
	
	e->taille = e->taille+1;
	e->prio = val;
	return e; 
}

Couple  ensGetFirst(Ens * e){
	Ens eorig = *e;
	Couple c;
	//case == NULL or c == NULL
	if(ensEstVide(eorig))
		return NULL;
	

	if (eorig->eNext == NULL ){//case first and only
		c = coupleCreate(eorig->c->x,eorig->c->y);
		free(eorig->c);
		eorig->c = NULL;
		eorig->taille = eorig->taille-1;
		*e = eorig;
	}else{//case first and not only
		c = coupleCreate(eorig->c->x,eorig->c->y);
		eorig->eNext->taille = eorig->eNext->taille-1;
		*e = eorig->eNext;
		elemFree(eorig);
	}

 	return c;
}

//When using this function, the return must imperatively be registered as init
//TODO ensSupprIeme that delete at i
Ens  ensSuppr(Ens e,int x, int y)
{
	Ens etmp = e->eNext;
	Ens eprev = e;

	if(ensEstVide(e)){
// 		puts("//////DEL: c'est vide");
		return e;

	}

	//Case c is the first element of ensemble
	if(cplcmp(e->c,x,y))
	{
		//case first and only
		if(eprev->eNext == NULL){
// 			printf("//////DEL :first only eprev(%d,%d) etmp(NULL)\n",eprev->c->x,eprev->c->y);
			free(e->c);
			e->c = NULL;
			e->taille = e->taille - 1;
			return e;
		}
		else{
		//case first and not only
// 			printf("//////DEL :first among eprev(%d,%d) etmp(%d,%d)\n",eprev->c->x,eprev->c->y,etmp->c->x,etmp->c->y);
			elemFree(e);
			etmp->taille = etmp->taille-1;
			return etmp;
		}

	}

	/* Case c is in the following element of the ensemble
	 * (last elem included, because swap something for NULL)
	 */
	while(etmp != NULL)
	{
// 		printf("//////DEL :check eprev(%d,%d) etmp(%d,%d)\n",eprev->c->x,eprev->c->y,etmp->c->x,etmp->c->y);
		if(cplcmp(etmp->c,x,y))
		{

			eprev->eNext = etmp->eNext;
			elemFree(etmp);
			e->taille = e->taille -1 ;

			return e;
		}
		eprev = etmp;
		etmp = etmp->eNext;

	}

// 	fprintf(stderr,"//////DEL : (%d,%d)not found\n",x,y);
	return NULL;
}

Couple  ensTirage(Ens* e)
{
	if(ensEstVide(*e))
		return NULL;

	twistInitialize(time(NULL));
	Ens eorig = *e;
	Ens eprev = eorig;
	Ens etmp = eprev->eNext;

	int l = twistExtractU32()%(ensTaille(*e));
	int i = 1;
	Couple c;
	
	//suppressing the undesired elem, without regoing trhough the whole ens	
	if(l == 0){
		
		if (etmp == NULL ){//case first and only
			c = coupleCreate(eorig->c->x,eorig->c->y);
			free(eorig->c);
			eorig->c = NULL; //important
			
			eorig->taille = eorig->taille - 1;
			*e = eorig;
			
		}else{//case first and not only
			c = coupleCreate(eprev->c->x,eprev->c->y);
			elemFree(eprev);
			etmp->taille = eorig->taille-1;
			*e = etmp;
		}
	} else { 
		//case in the following elements
		for(;i<l;i++){
			eprev = etmp;
			etmp = etmp->eNext;
		}
		c = coupleCreate(etmp->c->x,etmp->c->y);
		eprev->eNext = etmp->eNext;
		elemFree(etmp);
		eorig->taille = eorig->taille - 1 ;
		*e = eorig;
	} 
	
 	return c;
}

void ensAffiche(Ens e,char* ensName)
{
	printf("%s{\n taille : %d\n",ensName,e->taille);
	Ens etmp = e;

	if(ensEstVide(etmp))
	{printf("VIDE\n}\n"); return;}

	 int gf = 0;
	while(etmp && gf != 100)
	{
// 		puts("\nens");
// 		printf("ADR    : %p\n",(void*)&etmp->eNext);

		if(etmp->eNext != NULL){
 			printf("    %d:(%d,%d)--eNext-->(%d,%d)\n",gf,etmp->c->x,etmp->c->y,etmp->eNext->c->x,etmp->eNext->c->y);
// 			puts("\nens->eNext");
// 			printf("ADR    : %p\n",(void*)&etmp->eNext);
		}else{
 			printf("    %d:(%d,%d)--eNext-->NULL\n",gf,etmp->c->x,etmp->c->y);
		}
		etmp = etmp->eNext;
		gf++;
	}
	printf("};\n");
}
/*
int main(int argv,char* argc[])
{
	//CREATE
	puts("_____________________________________Ensemble de 4 elems :");
	Ens init = ensCreate(0,0);
	ensAjoute(init,1,1);
	ensAjoute(init,2,2);
	ensAjoute(init,3,3);

	ensAffiche(init,"E");

	//CRUD
	puts("_____________________________________///CRUD");
	puts("_____________________________________Delete (2,2)");
	init = ensSuppr(init,2,2);
	ensAffiche(init,"E");
	puts("_____________________________________Delete (0,0)");
	init = ensSuppr(init,0,0);
	ensAffiche(init,"E");
	puts("______________________________Delete (3,3)");
	init = ensSuppr(init,3,3);
	ensAffiche(init,"E");
	puts("_____________________________________Delete (1,1)");
	init = ensSuppr(init,1,1);
	ensAffiche(init,"E");
	puts("_____________________________________Adding (4,4)");
	ensAjoute(init,4,4);
	ensAffiche(init,"E");
	puts("_____________________________________Adding (4,4)");
	ensAjoute(init,1,1);
	ensAffiche(init,"E");

	//Bool Functions
	puts("_____________________________________///Bool");
	puts("_____________________________________(0,0) dans l'ensemble ?");
	puts(ensEstDans(init,0,0) ? "Oui" : "Non");
	puts("_____________________________________(1,1) dans l'ensemble ?");
	puts(ensEstDans(init,1,1) ? "Oui" : "Non");
	puts("_____________________________________(-9,0) dans l'ensemble ?");
	puts(ensEstDans(init,-9,0) ? "Oui" : "Non");
	puts("_____________________________________Taille 4 ?");
	puts((ensTaille(init) == 4) ? "Oui" : "Non");
	puts("_____________________________________Nouvel ensemble vide ?");
	Ens g = ensCreateEmpty();
	ensAffiche(g,"G");
	puts("_____________________________________G est-il vide ?");
	puts(ensEstVide(g) ? "Oui" : "Non");
	puts("_____________________________________Suppr 9,9 dans G ?");
	ensSuppr(g,9,9);
	puts("_____________________________________Suppr 9,9 dans E ? (sortie en stderr)");
	ensSuppr(init,9,9);
	//Rand
	puts("_____________________________________///Rand E->F");
	Ens initBis = ensCreateFromCouple(ensTirage(&init));
	ensAffiche(init,"E");
	ensAffiche(initBis,"F");
	//Rand
	puts("_____________________________________///Rand E->F");
	ensAjouteFromCouple(initBis,ensTirage(&init));
	ensAffiche(init,"E");
	ensAffiche(initBis,"F");

	puts("_____________________________________///Free");
	ensFree(init);
	ensFree(initBis);
	ensFree(g);
	return 1;
}
*/
