#ifndef HEADER_GENLAB
#define HEADER_GENLAB

#include <getopt.h>
#include "libEns.h"
#include "libMat.h"
#include "graph.h"
#include "twist.h"

matrice* generationLab(int h,int l);
void ajoutCaseConstructible(Couple c,matrice* m,Ens e);
int estConstructible(int x,int y,matrice* m);
Couple choixRand(int h,int l);


#endif
