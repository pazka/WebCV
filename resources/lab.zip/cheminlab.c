#include "cheminlab.h"

int verbose = 0,pt = 1;

void afficherCase(int x, int y , matrice * m){
	printf("\n%d,%d:\n%d%d%d\n%d%d%d\n%d%d%d\n",x,y
	,matVal(y-1,x-1,m),matVal(y-1,x,m),matVal(y-1,x+1,m)
	,matVal(y,x-1,m),matVal(y,x,m),matVal(y,x+1,m)
	,matVal(y+1,x-1,m),matVal(y+1,x,m),matVal(y+1,x+1,m)
	);
}

void afficherMark(int x, int y , matrice * m){
	printf("\n%d,%d:\n%d%d%d\n%d%d%d\n%d%d%d\n",x,y
	,matEstMark(y-1,x-1,m),matEstMark(y-1,x,m),matEstMark(y-1,x+1,m)
	,matEstMark(y,x-1,m),matEstMark(y,x,m),matEstMark(y,x+1,m)
	,matEstMark(y+1,x-1,m),matEstMark(y+1,x,m),matEstMark(y+1,x+1,m)
	);
}
 
Ens getWantToGo(Ens e, matrice * m,int x, int y){
	//haut
	if(!matVal(y+1,x,m) && !matEstMark(y+1,x,m))
		e=ensAjoute(e,x,y+1);
	//bas
	if(!matVal(y-1,x,m) && !matEstMark(y-1,x,m))
		e=ensAjoute(e,x,y-1);
	//droite 
	if(!matVal(y,x+1,m) && !matEstMark(y,x+1,m))
		e=ensAjoute(e,x+1,y);
	//gauche
	if(!matVal(y,x-1,m) && !matEstMark(y,x-1,m))
		e=ensAjoute(e,x-1,y);
	 
	return e;
}

void choixAleatoire(matrice * m){
	Stack path = stackCreate();
	Ens wantToGo = ensCreateEmpty();
	
	Couple ctmp, cprev;
	int noExit = 0;
	
	wantToGo = getWantToGo(wantToGo,m,1,1);
	path = push(path,1,1);
	matMark(1,1,1,m);
	      
	ctmp = head(path);  
	 
	while(!cplcmp(ctmp,m->l-2,m->h-2) && !noExit){ 
		//take a step forward 
		ctmp = ensTirage(&wantToGo);
		if(verbose>0 && verbose<2){afficherPointTmp(ctmp->x,ctmp->y,pt);}
		matMark(1,ctmp->y,ctmp->x,m);
		path = push(path,ctmp->x,ctmp->y); 
		
		
		//refresh the possibilities
		wantToGo = ensEmpty(wantToGo);
		wantToGo = getWantToGo(wantToGo,m,ctmp->x,ctmp->y);
		 
		// while nowhere to go, take a step backward 
		if(!cplcmp(ctmp,m->l-2,m->h-2))
		{
			while(ensEstVide(wantToGo)&& !noExit){
				ctmp = pop(&path);
				ctmp = head(path); 
				
				if(ctmp == NULL)
					noExit = -1;
				else
				wantToGo = getWantToGo(wantToGo,m,ctmp->x,ctmp->y);
				
			}
		} 
	}
	
	if (noExit == -1){
		printf("No exit\n");
	}else if(verbose>1){
		initgraph(m->l*pt,m->h*pt);
		afficherGraphMat(m,pt);
		afficheGraphStack(path,pt);
		refresh();
		waitgraph();
	}
	else if(verbose>0){afficheStack(path);afficheGraphStack(path,pt);waitgraph();}
	else
		afficheStack(path);
	
	ensFree(wantToGo);
	stackFree(path); 
}

//calcul de l distance minimum
int minDist(int *dist,int *inclus,matrice *m)
{
        int V=m->h*m->l,i=0;
        int min=INT_MAX,minInd;
        for(i;i<V;i++)
        {
                if(inclus[i]==0 && dist[i]<=min && m->content[i]!=1)
                {
                        min =dist[i];
                        minInd=i;
                }
        }
        return minInd;
}

//application et affichage de l'algorithme de Dijkstra
void dijkstra(matrice *m){

                int V=m->h*m->l;
                int dist[V];
                int inclus[V];
                int i=0,j=0,k=0;

                for(i;i<V;i++)
                {
                        dist[i]=INT_MAX,inclus[i]=0;
                }

                dist[0]=0;
                for(j;j<V-1;j++)
                {

                        int min=minDist(dist,inclus,m);
                        inclus[min]=1;
                        while(min!=(m->l-2)+(m->h-2)*m->l)
                        {
                                for(k;k<V;k++)
                                {
                                        if(!inclus[k] && dist[min] !=INT_MAX && dist[min]+1<dist[k])
                                                {
                                                        dist[k]=dist[min]+1;
                                                }
                                }
                        }

                }
                j=0;
                i=dist[(m->l-2)+(m->h-2)*m->l];
                while(i>0)
                {
                        for(j;j<V;j++)
                        {
                                if(dist[j]==dist[i]-1)
                                        afficherPointRed(inclus[j]/m->l,inclus[j]%m->l,pt);
                                        matMark2(1,inclus[j],m);
                        }

                        i=dist[j];
                }

                afficherMarkMat(m,pt);
}


//http://theory.stanford.edu/~amitp/GameProgramming/Heuristics.html
//we'll use here the manhatan distance.
int heuristic(int x, int y , matrice * m){
	return m->h-2 + m->l-2 - x - y; 
}
 
Ens getWantToGoNoMark(Ens e, matrice * m,int x, int y){	
	//haut
	if(!matVal(y+1,x,m)) 
		e=ensAjoute(e,x,y+1);
	//bas
	if(!matVal(y-1,x,m))
		e=ensAjoute(e,x,y-1);
	//droite 
	if(!matVal(y,x+1,m))
		e=ensAjoute(e,x+1,y);
	//gauche
	if(!matVal(y,x-1,m))
		e=ensAjoute(e,x-1,y);
	
	return e;
}
//http://www.redblobgames.com/pathfinding/a-star/introduction.html
void astar(matrice * m){
	//came from est stocké dans ensemble
	//cost so far = marquage
	
	//init
	int j , i,end = 0; 
	for(j=0;j<m->h;j++){for(i=0;i<m->l;i++){m->marquage[(j*m->l)+i]=INT_MAX;}}
	Couple predec[m->h*m->l];
	
	Ens wantToGo = ensCreateEmpty();
	Ens frontier = ensCreateEmpty(); 
	frontier = ensAjouteTriCroissant(frontier,1,1,0);
	Couple current;
	Couple next;
	int new_cost;
	
	matMark(0,1,1,m);  
	
	while (!end){
		
		current = ensGetFirst(&frontier);
		//il ne supprimme pas pb
		wantToGo = getWantToGoNoMark(wantToGo,m,current->x,current->y);
		
		
		if(ensEstVide(wantToGo)) 
			end = -1;
				
		while(!ensEstVide(wantToGo) && !end){
			new_cost = matEstMark(current->y,current->x,m) + 1;
			next = ensGetFirst(&wantToGo);
			
			if(!cplcmp(next,m->l-2,m->h-2) && !end){
				if(verbose>0  && verbose<2 ){afficherPointTmp(next->x,next->y,pt);}
				 
				if (new_cost < matEstMark(next->y,next->x,m)){ 
					matMark(new_cost,next->y,next->x,m);
					Ens eToAdd = ensCreate(next->x,next->y);
					
					//on met à jour le prédecesseur, de la case traitée
					predec[(eToAdd->c->y)*m->l+(eToAdd->c->x)] = coupleCreate(current->x,current->y);
					
					//la case traitée est ajoutée dans la frontiere avec sa priorité
					eToAdd->prio = heuristic(eToAdd->c->x,eToAdd->c->y,m);
					frontier = ensAjouteTriCroissantEns(frontier,eToAdd);
				}				
			}	 
			else{
				end = 1;
				predec[(m->h-2)*m->l+(m->l-2)] = coupleCreate(current->x,current->y);
				matMark(matEstMark(current->y,current->x,m) + 1,m->h-2,m->l-2,m);
			}
		}
		free(current);
	}
	   
	Couple ctmp = predec[(m->h-2)*m->l+(m->l-2)];
	
	if(end == -1)
		printf("No exit\n");
	else if (verbose>1){
		initgraph(m->l*pt,m->h*pt);
		afficherGraphMat(m,pt);
		while( !(ctmp->x == 1 && ctmp->y == 1)){
			printf("(%d,%d)",ctmp->x,ctmp->y);
			afficherPointRednr(ctmp->x,ctmp->y,pt);
			ctmp = predec[ctmp->y*m->l+ctmp->x];
		}
		printf("\nPath found in %d tiles\n",matEstMark(m->h-2,m->l-2,m));
		refresh();
		waitgraph();
	}else if(verbose>0){
		afficherPointTmp(next->x,next->y,pt);
		
		while( !(ctmp->x == 1 && ctmp->y == 1)){
			printf("(%d,%d)",ctmp->x,ctmp->y);
			afficherPointRed(ctmp->x,ctmp->y,pt);
			ctmp = predec[ctmp->y*m->l+ctmp->x];
		}
		printf("\nPath found in %d tiles\n",matEstMark(m->h-2,m->l-2,m));
		waitgraph();
	}else{
		while( !(ctmp->x == 1 && ctmp->y == 1)){
			printf("(%d,%d)",ctmp->x,ctmp->y);
			ctmp = predec[ctmp->y*m->l+ctmp->x];  
		}
		
		printf("\nPath found in %d tiles\n",matEstMark(m->h-2,m->l-2,m));
	}
	
	
	free(next);
// 	free(*predec);
 	ensFree(wantToGo);
	ensFree(frontier);
}

int main(int argc,char* argv[])
{
	int argstart = 1, opt = 0,mode = 0;
	char* file;
	
	while((opt = getopt(argc,argv,"v d f p: m:")) != -1){
		switch(opt)
		{
			case((int)'p'):
				if(optarg == NULL ){
					fprintf(stderr,"usage : %s [-v verbose] [-f affichageFin]  [-p pixelSize] [-m searchMode] fichier \n 0 - Random\n 1 - dijkstra\n 2 - A*\n",argv[0]);
					exit(1);
				} 
				sscanf(optarg,"%d",&pt);
				argstart += 2;
				break;

			case((int)'m'):
				if(optarg == NULL ){
					fprintf(stderr,"usage : %s [-v verbose]  [-f affichageFin] [-p pixelSize] [-m searchMode] fichier \n 0 - Random\n 1 - dijkstra\n 2 - A*\n",argv[0]);
					exit(1);
				}
				sscanf(optarg,"%d",&mode);
				argstart += 2;
				break;

			case((int)'v'):
				verbose += 1;
				argstart ++;
				break;
				
			case((int)'f'):
				verbose += 2;
				argstart ++;
				break;
 
			default:
				fprintf(stderr,"usage : %s [-v verbose] [-f affichageFin]  [-p pixelSize] [-m searchMode] fichier \n 0 - Random\n 1 - dijkstra\n 2 - A*\n",argv[0]);
				exit(1);
		}
	}              
	
	if(argv[argstart] == NULL){
		fprintf(stderr,"usage : %s [-v verbose] [-f affichageFin]  [-p pixelSize] [-m searchMode] fichier \n 0 - Random\n 1 - dijkstra\n 2 - A*\n",argv[0]);
		exit(1); 
	} 
	
	file = argv[argstart]; 
	matrice * m = matLit(file);
	
	if(m == NULL){
		fprintf(stderr,"File dosen't exist.\n");
		exit(1); 
	} 
	
	
	if(verbose>0 && verbose<2){initgraph(m->l*pt,m->h*pt);afficherGraphMat(m,pt);}
	switch(mode){
		case 0 :
			choixAleatoire(m);
			break;	
		
		case 1 :
			dijkstra(m);
			break;
		
		case 2 :
			astar(m);
			break;
			
		default:
			fprintf(stderr,"usage : %s [-v verbose] [-p pixelSize] [-m searchMode] fichier \n 0 - Random\n 1 - dijkstra\n 2 - A*\n",argv[0]);
			exit(1);
	}
	if(verbose>0){closegraph();}
	matFree(m); 
	return 0;
}
