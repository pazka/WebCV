#ifndef HEADER_TWIST
#define HEADER_TWIST
#include <stdint.h>

// Define MT19937 constants (32-bit RNG)
enum
{
    // Assumes W = 32 (omitting this)
    N = 624,
    M = 397,
    R = 31,
    A = 0x9908B0DF,

    F = 1812433253,

    U = 11,
    // Assumes D = 0xFFFFFFFF (omitting this)

    S = 7,
    B = 0x9D2C5680,

    T = 15,
    C = 0xEFC60000,

    L = 18,

    MASK_LOWER = (1ull << R) - 1,
    MASK_UPPER = (1ull << R)
};

void twistInitialize(const uint32_t  seed);
static void twist();

// Obtain a 32-bit random number
uint32_t twistExtractU32();
#endif