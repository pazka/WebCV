#ifndef HEADER_LIBENS
#define HEADER_LIBENS
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "twist.h"
#define MAX_VAL 100000


//typedef int couple[2]; don't work;
/* don't forget that ensemble will be passed by reference 
 */
typedef struct s_couple {
  int x,y;
} s_couple, * Couple;

typedef struct s_ens{
    Couple c;
    struct s_ens * eNext;
    int taille;
    int prio;
} s_ens, * Ens;

//Ens OPS
Ens  ensAlloc(void);
Ens ensCreate(int x, int y);
Ens ensCreateFromCouple(Couple c);
Ens ensCreateEmpty();
Ens ensEmpty(Ens e);
void ensFree(Ens e);
void elemFree(Ens e);
Couple coupleCreate(int x, int y);

//ajoute en temps  que premier élément
Ens  ensAjoute(Ens e,int x, int y);

//ajoute de manière triée
Ens  ensAjouteTriCroissant(Ens e,int x, int y,int val);

//ajoute de manière triée un ensemble
Ens  ensAjouteTriCroissantEns(Ens e,Ens eToAdd);

//obselete et non-fonctionnelle
Ens  ensAjouteFromCouple(Ens e,Couple c);

//retire de la liste e un élément au hasard et renvoi son couple
Couple  ensTirage(Ens* e);

//retire le premier élément de la liste e et renvoi le couple retiré
Couple  ensGetFirst(Ens * e);

//supprime l'élément correspondant aux x et y et renvoi la liste modofiée 
Ens  ensSuppr(Ens e,int x, int y);

int  ensEstDans(Ens e,int x, int y);
int  ensEstVide(const Ens e);
int  ensTaille(Ens e);
int cplcmp(Couple a, int x, int y);

void ensAffiche(Ens e,char * ensName);
#endif