#include "stack.h"

Stack stackCreate(){
	Stack s = malloc(sizeof(s_stack));
	s->c = NULL;
	s->next = NULL;
	s->taille = 0;
	return s;
}

void stackFree(Stack s){
// 	while (s->next != NULL)
// 		stackFree(s->next);
	
// 	printf("free (%d,%d)\n",s->c->x,s->c->y);
	sElemFree(s);
}

void sElemFree(Stack s){
	s->next = NULL;
	free(s->c);
	free(s); 
}

Stack push(Stack s,int x, int y){
	Couple c = coupleCreate(x,y);
	
	if(s->c == NULL){
		s->c = c;
		s->taille = 1;
	}
	Stack s1 = stackCreate();
	
	s1->c = c;
	s1->next = s;
	s1->taille = s->taille+1;
	
	return s1;
}

Couple pop(Stack *s){
	Stack sorig = *s;
	Couple c = sorig->c;
	
	if(sorig->next != NULL){
		sorig->next->taille = sorig->taille -1; //should be evident but just in case
		*s = sorig->next;
		sElemFree(sorig);
	}
	else {
		sorig->c = NULL;
		sorig->taille = 0;
	}
	
	
	return c;
}

int sEstVide(Stack s){
	if(s == NULL)
		return 1;
	
	return 0;
}

Couple head(Stack s){
	return s->c;
}

int afficheStackRec(Stack s,int i){
	if(s->next != NULL)
		i = afficheStackRec(s->next,i);
	printf("(%d,%d)",s->c->x,s->c->y);
	return ++i;
}

void afficheStack(Stack s){
	int i = 0; 
	i = afficheStackRec(s,i);
	printf("\nPath found in %d tiles\n",i);
}
