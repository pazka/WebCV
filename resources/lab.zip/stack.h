#ifndef HEADER_STACK
#define HEADER_STACK

#include <stdio.h>
#include "libEns.h"
 
typedef struct s_stack{
    Couple c;
    struct s_stack * next;
    int taille;
} s_stack, * Stack;

Stack stackCreate();
void stackFree(Stack s);
void sElemFree(Stack s);

Couple head(Stack s);
int sEstVide(Stack s);
Stack push(Stack s,int x, int y);
Couple pop(Stack *s);
void afficheStack(Stack s);

#endif