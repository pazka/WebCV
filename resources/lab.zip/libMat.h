#ifndef HEADER_LIBMAT
#define HEADER_LIBMAT
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

// Départ = mat[0,1]; Arrivée = mat[h,l-1];
typedef struct matrice
{
    int h;
    int l;
    int *content;
    int *marquage;
} matrice;

//création d’une nouvelle matrice h * l initialisée à 0
matrice* matAlloc(int h,int l);

//libération éventuelle de la mémoire utilisée
int matFree(matrice* mat);

int matMark2(int val,int ind,matrice* m);
int matEstMark(int h,int l,matrice* m);
int matMark(int val,int h,int l,matrice* m);

//renvoie la valeur entière matrice[x,y]
int matVal(int h,int l, matrice* m);

//stocke une valeur entière dans matrice[x,y]
int matSet(int val,int h, int l,matrice* m);

//enregistre une matrice dans un fichier
void matSauv(matrice* mat,char* path);

//lit une matrice dans un fichier
matrice* matLit(char* path);
/*ens.o : libEns.c libEns.h twist.o
	gcc -g libEns.c twist.o

mat.o : libMat.c libMat.h
	gcc -g libMat.c

gen.o : genLab.c
	gcc -g -c genLab.c -o gen.o

graph.o : graph.c graph.h
	gcc -g -c graph.c

twist.o : twist.c twist.h
	gcc -g -c twist.c -o twist.o

stack.o : stack.c stack.h
	gcc -g  stack.c -o stack.o

chemin.o : cheminlab.c mat.o
	gcc -g -c cheminlab.c -o chemin.o
*/
#endif
